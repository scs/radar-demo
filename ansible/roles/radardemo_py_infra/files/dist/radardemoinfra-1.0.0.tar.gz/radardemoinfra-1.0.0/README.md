# About this library
This library provides utilities to access the FPGA card through the serial
device. It also provides utilities to determine the ethernet devices for that
shall be used for IPv4 or IPv6.
